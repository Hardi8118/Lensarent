
export const images = {
  'Canon_EOS_80D.png': require('../assets/camera/Canon_EOS_80D.png'),
  'Canon_EOS_M5o.png': require('../assets/camera/Canon_EOS_M5o.png'),
  'Fujifilm_X-T30.png': require('../assets/camera/Fujifilm_X-T30.png'),
  'Fujifilm_X-T4.png': require('../assets/camera/Fujifilm_X-T4.png'),
  'Nikon_D3500.png': require('../assets/camera/Nikon_D3500.png'),
  'Nikon_Z50.png': require('../assets/camera/Nikon_Z50.png'),
  'Olympus_OM-D_E-M10 Mark_III.png': require('../assets/camera/Olympus_OM-D_E-M10 Mark_III.png'),
  'Panasonic_Lumix_G7.png': require('../assets/camera/Panasonic_Lumix_G7.png'),
  'Sony_Alpha_a6000.png': require('../assets/camera/Sony_Alpha_a6000.png'),
  'Sony_Alpha_a7.png': require('../assets/camera/Sony_Alpha_a7.png')
};
